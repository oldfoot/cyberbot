<?php
$website_directory = "c:/xampp/htdocs/cyberbot/";

$database_server = "localhost";
$database_port = 3306;
$database_database = "cyberbot";
$database_user = "root";
$database_password = "root";
?>